-- Part 2.3 select.sql
--
-- Submitted by: Xinran Tao, 1834437
--

-- DO NOT use these SQL commands in your submission(they will cause an
--  error on the NMS database server):
-- CREATE SCHEMA
-- USE


-- 1. Average Female Salary
SELECT AVG(DailySalary) AS AverageFemaleSalary
FROM PARTICIPANT
WHERE Gender = "Female";


-- 2. Coaching Report.
--not using SELECT* to avoid duplicate columns.
SELECT FName, SName, IDCoach, DoB, Phone, DailySalary, Gender, COUNT(IDContender) AS NumOfContender
FROM (COACH LEFT JOIN CONTENDER
    ON IDCoach = Coach)
GROUP BY Coach;




-- 3. Coach Monthly Attendance Report
--Not using SELECT* because we don't want duplicate information
--This query retrives the required information from a join subtable with condition
--of the same CoachID. It has a inner join, also with the condition of the same
--CoachID, of each coach and his/her monthly attendance.
--not using SELECT* to avoid duplicate columns.
SELECT FName, SName, IDCoach, DoB, Phone, DailySalary, Gender, MarchAttence, AprilAttendance
FROM(
    (SELECT*
      FROM COACH) AS CoachInformation
JOIN
    (SELECT a, MarchAttence, AprilAttendance
     FROM(
        (SELECT Coach AS a, COUNT(*) AS MarchAttence, ShowDate
        FROM COACHINSHOW, TVSHOW
        WHERE ShowDate <= "2019-03-31"
        AND CoachShow = IDShow
        GROUP BY Coach) AS MarchData
     JOIN
        (SELECT Coach AS b, COUNT(*) AS AprilAttendance, ShowDate
        FROM COACHINSHOW, TVSHOW
        WHERE ShowDate > "2019-03-31"
        AND CoachShow = IDShow
        GROUP BY Coach) AS AprilData
     ON a = b)
   ) AS MonthlyCount
ON IDCoach = a
);

-- 4. Most Expensive Contender
--Subtable RichestContender is aim to FindRichestContender
--It finds the highest contender salary first, joins the DailySalary (ie DS)
--with ContenderDSInfo, and picks the contender that satisfies
--the condition TotalDS = MaxDS
--We only want the StageName as the result.
SELECT StageName
FROM (
  SELECT StageName, IDContender
  FROM CONTENDER
  WHERE IDContender = (
      SELECT Contender
      FROM(
        SELECT Contender, MaxDS, TotalDS
        FROM(
          (SELECT MAX(Total) AS MaxDS
           FROM(
             SELECT SUM(DailySalary) AS Total, Contender
             FROM PARTICIPANT, CONTENDER
             WHERE Contender = IDContender
             GROUP BY Contender
           ) AS SumDSOfEachContender
         ) AS MaxDSContender
       JOIN
        (SELECT SUM(DailySalary) AS TotalDS, Contender
         FROM PARTICIPANT, CONTENDER
         WHERE Contender = IDContender
         GROUP BY Contender) AS ContenderDSInfo
       )
       WHERE TotalDS = MaxDS
     ) AS FindRichestContender
   )
) AS RichestContender;

-- 5. March Payment Report
--This quesry contains three parts: 1. Coach Payment Report; 2. Participant
--Payment Report; 3. GrandTotal.
--1 joins the tables of COACH and shows information for them based on the same Coach ID.
--2 joins the tables of PARTICIPANT and shows information for them based on the same contender ID.
--3 sums the total monthly salary for all coaches/participants,
--and joins the table of COACH/PARTICIPANT and NoOfShows based on the same coach/participant ID.
--It then calculates the GrandTotal from MonthlySForC ahd MonthlySForP from the subtable which joins
--the table AllCoachesTotalSalaryCalc and AllParticipantsTotalSalaryCalc without a condition,
--because only two tuples are returned.
--then in order to get only one table as the result, 1 UNION 2 (as they have the same number of columns)
--then the coombined table CONCAT() to contain only one column.
--Finally, the it UNION GrandTotal to present the final view.
(SELECT CONCAT("Name: ", FName, " ", SName, " NoOfShows: ", NoOfShows, " DailySalary: ", DailySalary, " TotalSalary: ", TotalSalary) AS MarchPaymentReport
FROM(
(SELECT FName, SName, NoOfShows, DailySalary, DailySalary*NoOfShows AS TotalSalary
FROM(
    (SELECT FName, SName, DailySalary, IDCoach
     FROM COACH) AS CoachInformation
  JOIN
    (SELECT NoOfShows, Coach
     FROM(
       SELECT Coach, COUNT(*) AS NoOfShows, ShowDate
       FROM COACHINSHOW, TVSHOW
       WHERE ShowDate <= "2019-03-31"
       AND CoachShow = IDShow
       GROUP BY Coach) AS CoachShowInformation
    ) AS CoachShowCount
  ON IDCoach = Coach
 )
)

UNION


(SELECT FName, SName, NoOfShows, DailySalary, DailySalary*NoOfShows AS TotalSalary
FROM(

    (SELECT FName, SName, DailySalary, Contender AS a
     FROM PARTICIPANT) AS ParticipantInformation
  JOIN
   (SELECT Contender AS b, COUNT(*) AS NoOfShows, ShowDate
    FROM CONTENDERINSHOW, TVSHOW
    WHERE ShowDate <= "2019-03-31"
    AND ContenderShow = IDShow
    GROUP BY Contender) AS ParticipantShowInformation
  ON a = b
  )
 )
) AS IndividualPaymentReport)


UNION


(SELECT MonthlySForC + MonthylySForP AS GrandTotal
FROM(
    (SELECT SUM(MonthlyS) AS MonthlySForC
     FROM(
       SELECT DailySalary*NoOfShows AS MonthlyS
       FROM(
         (SELECT DailySalary, IDCoach
          FROM COACH) AS CoachDSInfo
        JOIN
        (SELECT NoOfShows, Coach
         FROM(
           SELECT Coach, COUNT(*) AS NoOfShows, ShowDate
           FROM COACHINSHOW, TVSHOW
           WHERE ShowDate <= "2019-03-31"
           AND CoachShow = IDShow
           GROUP BY Coach) AS CoachShowInfo
        ) CoachShowCount
        ON IDCoach = Coach
       )
     ) AS SingleCoachTotalSalaryCalc
   ) AS AllCoachesTotalSalaryCalc
JOIN
    (SELECT SUM(MonthlyS) AS MonthylySForP
     FROM(
       SELECT DailySalary*NoOfShows AS MonthlyS
       FROM(
         (SELECT DailySalary, Contender AS a
          FROM PARTICIPANT) AS ParticipantDSInfo
        JOIN
         (SELECT Contender AS b, COUNT(*) AS NoOfShows, ShowDate
          FROM CONTENDERINSHOW, TVSHOW
          WHERE ShowDate <= "2019-03-31"
          AND ContenderShow = IDShow
          GROUP BY Contender) AS ContenderShowInfo
        ON a = b
        )
      ) AS SingleParticipantTotalSalaryCalc
    ) AS AllParticipantsTotalSalaryCalc
  )
);
--Btw I honestly don't know why we must combine the tables together in this Q
--It just looks extremely ugly.
--I prefer the original layout and that just makes more sense.

-- 6. Well Formed Groups!
--create a group contender with only one participant for the sake of testing this selection query
INSERT INTO CONTENDER
VALUES("Deep Dark Fantasy", "Group", "9812345", "7566666");
INSERT INTO PARTICIPANT
VALUES("Dawei", "Tong", "1979-02-03", "6366666", "07453990666", "5000", "Male", "9812345");

--once there is a violation to the gourp constraint then the whole statement is flase
--Subtable GroupContender counts the number of participants in each gourp contender
--Subtable ViolationCount counts the number of violations
SELECT CASE WHEN (violation > 0) THEN "False" ELSE "True"
END AS NoViolationToGroupConstraint
FROM(
  SELECT COUNT(IDContender) AS Violation
  FROM(
    SELECT COUNT(IDParticipant) AS NoOfP, ContenderType, Contender, IDContender
    FROM PARTICIPANT, CONTENDER
    WHERE ContenderType = "Group"
    AND Contender = IDContender
    GROUP BY Contender
  ) AS GroupContender
  WHERE NoOfP = 1
) AS ViolationCount;
