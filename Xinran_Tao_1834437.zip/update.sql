-- Part 2.4 update.sql
--
-- Submitted by: Xinran Tao, 1834437
--
--Q1
--Change the calculation of salary from daily to hourly
--by dividing the DailySalary by 4
UPDATE COACH
SET DailySalary = DailySalary/4;
--change the name of the attribute
ALTER TABLE COACH
CHANGE DailySalary HourlySalary INTEGER;
--Change the calculation of salary from daily to hourly
--by dividing the DailySalary by 4
UPDATE PARTICIPANT
SET DailySalary = DailySalary/4;
--change the name of the attribute
ALTER TABLE PARTICIPANT
CHANGE DailySalary HourlySalary INTEGER;

--Q2
--add two new attributes ArrivingTime and LeavingTime to
--table COACHINSHOW
ALTER TABLE COACHINSHOW
ADD ArrivingTime TIME;
ALTER TABLE COACHINSHOW
ADD LeavingTime TIME;
--add two new attributes ArrivingTime and LeavingTime to
--table CONTENDERINSHOW
ALTER TABLE CONTENDERINSHOW
ADD ArrivingTime TIME;
ALTER TABLE CONTENDERINSHOW
ADD LeavingTime TIME;

--Q3
--update ArrivingTime and LeavingTime for all coaches
UPDATE COACHINSHOW
SET ArrivingTime = "18:00:00", LeavingTime = "22:00:00"
WHERE CoachShow = "0000001";
UPDATE COACHINSHOW
SET ArrivingTime = "19:00:00", LeavingTime = "23:00:00"
WHERE CoachShow = "0000002";
UPDATE COACHINSHOW
SET ArrivingTime = "18:00:00", LeavingTime = "22:00:00"
WHERE CoachShow = "0000003";
UPDATE COACHINSHOW
SET ArrivingTime = "19:00:00", LeavingTime = "23:00:00"
WHERE CoachShow = "0000004";
UPDATE COACHINSHOW
SET ArrivingTime = "18:00:00", LeavingTime = "22:00:00"
WHERE CoachShow = "0000005";
UPDATE COACHINSHOW
SET ArrivingTime = "19:00:00", LeavingTime = "23:00:00"
WHERE CoachShow = "0000006";
UPDATE COACHINSHOW
SET ArrivingTime = "18:00:00", LeavingTime = "22:00:00"
WHERE CoachShow = "0000007";
UPDATE COACHINSHOW
SET ArrivingTime = "19:00:00", LeavingTime = "23:00:00"
WHERE CoachShow = "0000008";
UPDATE COACHINSHOW
SET ArrivingTime = "18:00:00", LeavingTime = "22:00:00"
WHERE CoachShow = "0000009";
UPDATE COACHINSHOW
SET ArrivingTime = "19:00:00", LeavingTime = "23:00:00"
WHERE CoachShow = "0000010";
UPDATE COACHINSHOW
SET ArrivingTime = "18:00:00", LeavingTime = "22:00:00"
WHERE CoachShow = "0000011";
UPDATE COACHINSHOW
SET ArrivingTime = "19:00:00", LeavingTime = "23:00:00"
WHERE CoachShow = "0000012";
UPDATE COACHINSHOW
SET ArrivingTime = "18:00:00", LeavingTime = "22:00:00"
WHERE CoachShow = "0000013";
UPDATE COACHINSHOW
SET ArrivingTime = "19:00:00", LeavingTime = "23:00:00"
WHERE CoachShow = "0000014";
UPDATE COACHINSHOW
SET ArrivingTime = "18:00:00", LeavingTime = "22:00:00"
WHERE CoachShow = "0000015";
UPDATE COACHINSHOW
SET ArrivingTime = "19:00:00", LeavingTime = "23:00:00"
WHERE CoachShow = "0000016";
UPDATE COACHINSHOW
SET ArrivingTime = "18:00:00", LeavingTime = "22:00:00"
WHERE CoachShow = "0000017";
UPDATE COACHINSHOW
SET ArrivingTime = "19:00:00", LeavingTime = "23:00:00"
WHERE CoachShow = "0000018";
--update ArrivingTime and LeavingTime for all contenders
UPDATE CONTENDERINSHOW
SET ArrivingTime = "18:00:00", LeavingTime = "22:00:00"
WHERE ContenderShow = "0000001";
UPDATE CONTENDERINSHOW
SET ArrivingTime = "19:00:00", LeavingTime = "23:00:00"
WHERE ContenderShow = "0000002";
UPDATE CONTENDERINSHOW
SET ArrivingTime = "18:00:00", LeavingTime = "22:00:00"
WHERE ContenderShow = "0000003";
UPDATE CONTENDERINSHOW
SET ArrivingTime = "19:00:00", LeavingTime = "23:00:00"
WHERE ContenderShow = "0000004";
UPDATE CONTENDERINSHOW
SET ArrivingTime = "18:00:00", LeavingTime = "22:00:00"
WHERE ContenderShow = "0000005";
UPDATE CONTENDERINSHOW
SET ArrivingTime = "19:00:00", LeavingTime = "23:00:00"
WHERE ContenderShow = "0000006";
UPDATE CONTENDERINSHOW
SET ArrivingTime = "18:00:00", LeavingTime = "22:00:00"
WHERE ContenderShow = "0000007";
UPDATE CONTENDERINSHOW
SET ArrivingTime = "19:00:00", LeavingTime = "23:00:00"
WHERE ContenderShow = "0000008";
UPDATE CONTENDERINSHOW
SET ArrivingTime = "18:00:00", LeavingTime = "22:00:00"
WHERE ContenderShow = "0000009";
UPDATE CONTENDERINSHOW
SET ArrivingTime = "19:00:00", LeavingTime = "23:00:00"
WHERE ContenderShow = "0000010";
UPDATE CONTENDERINSHOW
SET ArrivingTime = "18:00:00", LeavingTime = "22:00:00"
WHERE ContenderShow = "0000011";
UPDATE CONTENDERINSHOW
SET ArrivingTime = "19:00:00", LeavingTime = "23:00:00"
WHERE ContenderShow = "0000012";
UPDATE CONTENDERINSHOW
SET ArrivingTime = "18:00:00", LeavingTime = "22:00:00"
WHERE ContenderShow = "0000013";
UPDATE CONTENDERINSHOW
SET ArrivingTime = "19:00:00", LeavingTime = "23:00:00"
WHERE ContenderShow = "0000014";
UPDATE CONTENDERINSHOW
SET ArrivingTime = "18:00:00", LeavingTime = "22:00:00"
WHERE ContenderShow = "0000015";
UPDATE CONTENDERINSHOW
SET ArrivingTime = "19:00:00", LeavingTime = "23:00:00"
WHERE ContenderShow = "0000016";
UPDATE CONTENDERINSHOW
SET ArrivingTime = "18:00:00", LeavingTime = "22:00:00"
WHERE ContenderShow = "0000017";
UPDATE CONTENDERINSHOW
SET ArrivingTime = "19:00:00", LeavingTime = "23:00:00"
WHERE ContenderShow = "0000018";
-- DO NOT use these SQL commands in your submission(they will cause an
--  error on the NMS database server):
-- CREATE SCHEMA
-- USE
