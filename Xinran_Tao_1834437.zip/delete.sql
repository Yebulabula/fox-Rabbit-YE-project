-- Part 2.5 delete.sql
--
-- Submitted by: Xinran Tao, 1834437
--
--Delete the unhappy contender
--All information about that contender will be deleted
--(inlcuding info from tables PARTICIPANT and CONTENDERINSHOW)
--because the foreign key constraint is ON DELETE CASCADE
--Subtable PoorestContender is aim to FindPoorestContender
--It finds the lowest contender salary first, joins the HourlySalary (ie HS)
--with ContenderDSInfo, and picks the contender that satisfies
--the condition TotalDS = MinDS
DELETE FROM CONTENDER
WHERE StageName =(
  SELECT StageName
  FROM (
    SELECT StageName, IDContender
    FROM CONTENDER
    WHERE IDContender = (
      SELECT Contender
      FROM(
        SELECT Contender, MinHS, TotalHS
        FROM(
          (SELECT MIN(Total) AS MinHS
           FROM(
             SELECT SUM(HourlySalary) AS Total, Contender
             FROM PARTICIPANT, CONTENDER
             WHERE Contender = IDContender
             GROUP BY Contender
           ) AS SumHSOfEachContender
         ) AS MinHSContender

       JOIN
        (SELECT SUM(HourlySalary) AS TotalHS, Contender
         FROM PARTICIPANT, CONTENDER
         WHERE Contender = IDContender
         GROUP BY Contender) AS ContenderHSInfo
       )
       WHERE TotalHS = MinHS
     ) AS FindPoorestContender
   )
 ) AS PoorestContender
);
--To test whether all the information has been deleted
--the SELECT queries give you errors when you run them in the compiler

-- DO NOT use these SQL commands in your submission(they will cause an
--  error on the NMS database server):
-- CREATE SCHEMA
-- USE
